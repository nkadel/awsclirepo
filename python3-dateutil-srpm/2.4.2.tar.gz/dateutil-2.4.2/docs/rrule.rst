=====
rrule
=====
The rrule module offers a small, complete, and very fast, implementation of the recurrence rules documented in the iCalendar RFC, including support for caching of results. 

.. automodule:: dateutil.rrule
   :members:
   :undoc-members:
